import React from 'react'
import './Expenses.css'
import Card from '../Card'
import ExpenseItem from './ExpenseItem'

function Expenses(props) {
	return (
		<>
			{props.data.map((e) => (
				<Card className='expense'>
					<ExpenseItem
						title={e.title}
						amount={e.amount}
						date={e.date}
					/>
				</Card>
			))}
		</>
	)
}

export default Expenses
